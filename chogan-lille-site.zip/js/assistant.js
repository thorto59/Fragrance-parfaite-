(function(){
// Assistant à règles, sans IA. Pour ajouter une langue : copier un bloc de T et traduire.
const T={
fr:{btn:'Un conseil ?',hi:'Coucou 😊 Je peux t’aider à trouver un parfum ou un produit, sans pression. On y va ?',who:'C’est pour quoi ou pour qui ?',mood:'Quelle ambiance te tente ?',bud:'Un budget en tête ?',
w:{Femme:'Parfum femme',Homme:'Parfum homme',Mixte:'Parfum mixte',Maison:'Parfum d’ambiance',Soin:'Soin'},b:['Jusqu’à 20 €','20 à 40 €','Plus de 40 €','Peu importe'],any:'Peu importe',
res:'Voilà quelques idées, à ton rythme :',none:'Je n’ai rien trouvé avec ça. On essaie autrement ?',gel:'Il existe aussi en gel douche',cre:'et en crème de corps',again:'Recommencer',ask:'Tu peux ensuite ajouter ce que tu veux à ta demande, rien n’est payé sur le site.',close:'Fermer',lang:'English'},
en:{btn:'Need a hint?',hi:'Hi 😊 I can help you find a fragrance or product, no pressure. Shall we?',who:'What is it for?',mood:'Which mood appeals to you?',bud:'Any budget in mind?',
w:{Femme:'Women’s fragrance',Homme:'Men’s fragrance',Mixte:'Unisex fragrance',Maison:'Home fragrance',Soin:'Skincare'},b:['Up to €20','€20 to €40','Over €40','No preference'],any:'No preference',
res:'Here are a few ideas, at your own pace:',none:'I found nothing with that. Shall we try differently?',gel:'Also available as shower gel',cre:'and body cream',again:'Start over',ask:'You can then add whatever you like to your request. Nothing is paid on the site.',close:'Close',lang:'Français'}};
const nl=(navigator.language||'en').slice(0,2).toLowerCase();let L=T[nl]?nl:'en',fallback=!T[nl];
const E=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let S={},open=false;
const b=document.createElement('button');b.id='ai-b';b.type='button';b.setAttribute('aria-expanded','false');b.setAttribute('aria-controls','ai-p');
const p=document.createElement('div');p.id='ai-p';p.hidden=true;p.setAttribute('role','dialog');p.setAttribute('aria-label','Assistant');
document.addEventListener('DOMContentLoaded',()=>{document.body.append(b,p);b.textContent=T[L].btn;});
b.onclick=async()=>{open=!open;p.hidden=!open;b.setAttribute('aria-expanded',open);if(open&&!p.innerHTML){await window.CH.load();start()}};
function say(t){p.insertAdjacentHTML('beforeend','<div class="ai-m">'+t+'</div>')}
function opts(a,fn){const d=document.createElement('div');d.className='ai-o';a.forEach(([l,v])=>{const x=document.createElement('button');x.type='button';x.textContent=l;x.onclick=()=>{d.remove();fn(v)};d.appendChild(x)});p.appendChild(d);p.scrollTop=p.scrollHeight}
function start(){S={};p.innerHTML='';const t=T[L];say(t.hi);if(fallback&&L==='en')opts([['Français','fr'],['English','en']],v=>{L=v;fallback=false;b.textContent=T[L].btn;start()});else step1()}
function step1(){const t=T[L];say(t.who);opts(Object.entries(t.w),v=>{S.who=v;S.who==='Maison'?step2():step3()})}
function step2(){const t=T[L];const ds=window.CH.data.filter(x=>x.famille_olfactive),set=new Set();
ds.forEach(x=>x.famille_olfactive.split(/[ ,]+/).forEach(w=>{if(w.length>3)set.add(w==='Fruit'?'Fruité':w)}));
say(t.mood);opts([...[...set].sort().map(w=>[w,w]),[t.any,'']],v=>{S.mood=v;step3()})}
function step3(){const t=T[L];say(t.bud);opts(t.b.map((l,i)=>[l,i]),v=>{S.bud=v;res()})}
function res(){const t=T[L],R=[[0,20],[20,40],[40,1e9],[0,1e9]][S.bud],w=S.who;
let r=window.CH.data.filter(x=>{const m=window.CH.mins(x);if(m==null||m<R[0]||m>=R[1])return false;
if(['Femme','Homme','Mixte'].includes(w))return x.famille==='Parfums'&&x.categorie===w;
if(w==='Maison')return x.famille==='Diffuseurs d\'ambiance'&&(!S.mood||(x.famille_olfactive||'').replace('Fruit ','Fruité ').includes(S.mood));
return x.famille==='Soins Aurodhea'});
r=r.sort(()=>Math.random()-.5).slice(0,4);
if(!r.length){say(t.none)}else{say(t.res+'<ul>'+r.map(x=>{const ex=[];if(x.gel_douche)ex.push(t.gel);if(x.creme_corps)ex.push(t.cre);
return'<li><a href="produit.html?id='+encodeURIComponent(x.id)+'">'+E(x.nom)+'</a>'+((x.marque_inspiree||x.gamme)?' ('+E(x.marque_inspiree||x.gamme)+')':'')+' – '+window.CH.eur(window.CH.mins(x))+(ex.length?'<br><small>'+ex.join(' ')+'</small>':'')+'</li>'}).join('')+'</ul>'+t.ask)}
opts([[t.again,1],[t.lang,2]],v=>{if(v===2){L=L==='fr'?'en':'fr';b.textContent=T[L].btn}start()})}
})();
