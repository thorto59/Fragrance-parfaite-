(function(){
const C=window.CHOGAN_CONFIG||{},$=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const eur=n=>n.toLocaleString('fr-FR',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2})+' €';
const src=u=>(window.__IMG__&&window.__IMG__[u])||u;
const lbl=f=>f.ml?f.ml+' ml':(f.contenance||'');
const mins=p=>{const a=(p.formats||[]).map(f=>f.prix);return a.length?Math.min(...a):null};
let DATA=[];
async function load(){if(DATA.length)return DATA;try{DATA=(await (await fetch('data/catalogue.json')).json()).produits}catch(e){$('main').insertAdjacentHTML('afterbegin','<p class="err">Impossible de charger le catalogue. Ouvre le site via Netlify (ou un serveur local), pas en double-cliquant sur le fichier.</p>')}return DATA}
window.CH={load,esc,eur,lbl,mins,get data(){return DATA}};
const KEY='chogan_demande';
const cart={get(){try{return JSON.parse(localStorage.getItem(KEY))||[]}catch(e){return[]}},set(a){try{localStorage.setItem(KEY,JSON.stringify(a))}catch(e){}badge()},
add(it){const a=this.get(),k=a.find(x=>x.id===it.id&&x.f===it.f&&x.x===it.x);k?k.q+=it.q:a.push(it);this.set(a);toast('Ajouté à ta demande ✓')}};
window.CH.cart=cart;
function line(p,it){if(it.x==='gel')return{nom:'Gel douche – '+p.nom,fmt:p.gel_douche.ml+' ml',prix:p.gel_douche.prix};
if(it.x==='creme')return{nom:'Crème de corps – '+p.nom,fmt:p.creme_corps.ml+' ml',prix:p.creme_corps.prix};
const f=(p.formats||[])[it.f];return{nom:p.nom,fmt:f?lbl(f):'',prix:f?f.prix:null}}
window.CH.line=line;
function badge(){const n=cart.get().reduce((s,x)=>s+x.q,0),b=$('#nb');if(b)b.textContent=n||''}
function toast(t){const d=document.createElement('div');d.className='toast';d.setAttribute('role','status');d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),2200)}
function chrome(){
$('#h').innerHTML='<a class="skip" href="#m">Aller au contenu</a><div class="bar"><a class="logo" href="index.html">CHOGAN <b>Lille</b></a><nav class="nav" aria-label="Navigation"><a href="catalogue.html">Catalogue</a><a href="demande.html">Ma demande<span class="badge" id="nb"></span></a></nav></div>';
$('#f').innerHTML='<p>CHOGAN Lille – Lille (Nord)</p><p>Aucun paiement sur ce site. <a href="mentions.html">Mentions légales et confidentialité</a></p>';badge()}
function vis(p,cls){return p.image?'<div class="ph ph-img'+(cls||'')+'"><img loading="lazy" src="'+src(p.image)+'" alt="'+esc(p.nom)+'"><span>'+esc(p.marque_inspiree||p.gamme||p.famille)+'</span></div>':'<div class="ph"><span>'+esc(p.marque_inspiree||p.famille)+'</span></div>'}
function card(p){const m=mins(p),mu=(p.formats||[]).length>1?'dès ':'';
return '<a class="card" href="produit.html?id='+encodeURIComponent(p.id)+'">'+vis(p)+'<div class="cb"><small>'+esc(p.reference||'')+(p.famille!=='Parfums'&&p.gamme?' · '+esc(p.gamme):'')+'</small><h3>'+esc(p.nom)+'</h3><p>'+(m==null?'Prix à confirmer':mu+eur(m))+'</p></div></a>'}
const P=new URLSearchParams(location.search);
const pages={
async index(){const d=await load();$$('.cnt').forEach(e=>{e.textContent=d.filter(p=>p.famille==='Parfums'&&p.categorie===e.dataset.cat).length+' parfums'});const f=$('#sf');f.onsubmit=e=>{e.preventDefault();location.href='catalogue.html?q='+encodeURIComponent($('#sq').value)};
['Femme','Homme','Mixte'].forEach(c=>{});},
async catalogue(){const d=await load(),fam=[...new Set(d.map(p=>p.famille))],marques=[...new Set(d.map(p=>p.marque_inspiree).filter(Boolean))].sort();
const fmts=[...new Set(d.flatMap(p=>(p.formats||[]).map(lbl)))].sort((a,b)=>parseFloat(a)-parseFloat(b)||a.localeCompare(b));
const opt=(a,all)=>'<option value="">'+all+'</option>'+a.map(x=>'<option>'+esc(x)+'</option>').join('');
$('#ff').innerHTML=opt(fam,'Toutes');$('#fc').innerHTML=opt(['Femme','Homme','Mixte'],'Toutes');$('#fm').innerHTML=opt(marques,'Toutes');$('#fo').innerHTML=opt(fmts,'Tous');$('#fa').innerHTML=opt([...new Set(d.map(p=>p.gamme).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'fr')),'Toutes');
['famille:ff','cat:fc','q:fq','gamme:fa'].forEach(s=>{const[k,id]=s.split(':');if(P.get(k))$('#'+id).value=P.get(k)});
let shown=60;
const run=()=>{const q=$('#fq').value.trim().toLowerCase(),F=$('#ff').value,Ca=$('#fc').value,Ga=$('#fa').value,M=$('#fm').value,O=$('#fo').value,B=$('#fb').value,G=$('#fg').checked,K=$('#fk').checked,S=$('#fs').value;
let r=d.filter(p=>{if(F&&p.famille!==F)return false;if(Ca&&p.categorie!==Ca)return false;if(Ga&&p.gamme!==Ga)return false;if(M&&p.marque_inspiree!==M)return false;
if(O&&!(p.formats||[]).some(f=>lbl(f)===O))return false;if(G&&!p.gel_douche)return false;if(K&&!p.creme_corps)return false;
const m=mins(p);if(B){if(m==null)return false;const[a,b]=B.split('-').map(Number);if(m<a||m>=b)return false}
if(q&&!(p.nom+' '+(p.marque_inspiree||'')+' '+(p.reference||'')+' '+p.famille+' '+(p.gamme||'')).toLowerCase().includes(q))return false;return true});
r.sort((a,b)=>S==='p+'?(mins(a)??1e9)-(mins(b)??1e9):S==='p-'?(mins(b)??-1)-(mins(a)??-1):a.nom.localeCompare(b.nom,'fr'));
$('#cnt').textContent=r.length+' produit'+(r.length>1?'s':'');$('#gr').innerHTML=r.slice(0,shown).map(card).join('')||'<p>Aucun résultat. Essaie de retirer un filtre.</p>';$('#more').hidden=r.length<=shown};
$$('#flt input,#flt select').forEach(e=>e.addEventListener('input',()=>{shown=60;run()}));$('#more').onclick=()=>{shown+=60;run()};run()},
async produit(){const d=await load(),p=d.find(x=>x.id===P.get('id')),el=$('#pd');if(!p){el.innerHTML='<p>Produit introuvable. <a href="catalogue.html">Retour au catalogue</a></p>';return}
document.title=p.nom+' – CHOGAN Lille';const fs=p.formats||[];let h='<p><a href="catalogue.html">← Catalogue</a></p><div class="pg"><div class="vis">'+vis(p)+'</div><div><div class="chips"><span>'+esc(p.famille)+'</span>'+(p.categorie?'<span>'+esc(p.categorie)+'</span>':'')+(p.gamme?'<span>'+esc(p.gamme)+'</span>':'')+'</div><h1>'+esc(p.nom)+'</h1>';
if(p.marque_inspiree)h+='<p class="brand">Inspiré de '+esc(p.marque_inspiree)+'</p>';if(p.marque)h+='<p>'+esc(p.marque)+'</p>';
if(p.reference)h+='<p>Réf. <strong>'+esc(p.reference)+'</strong></p>';

if(p.famille_olfactive)h+='<p>'+esc(p.famille_olfactive)+(p.pieces?' · idéal : '+esc(p.pieces):'')+'</p>';
if(p.notes)h+='<p><strong>Tête :</strong> '+esc(p.notes.tete)+'<br><strong>Cœur :</strong> '+esc(p.notes.coeur)+'<br><strong>Fond :</strong> '+esc(p.notes.fond)+'</p>';
if(p.ingredients)h+='<p><strong>Composition :</strong> '+esc(p.ingredients)+'</p>';if(p.contenu)h+='<p>'+esc(p.contenu)+'</p>';
h+='<h2>Formats et prix</h2>';
if(fs.length)h+='<div class="fmt" role="radiogroup" aria-label="Format">'+fs.map((f,i)=>'<label><input type="radio" name="fmt" value="'+i+'"'+(i?'':' checked')+'> '+esc(lbl(f))+' – <strong>'+eur(f.prix)+'</strong>'+(f.reference?' <small>(réf. '+esc(f.reference)+')</small>':'')+(f.dimensions?' <small>('+esc(f.dimensions)+')</small>':'')+'</label>').join('')+'</div>';else h+='<p>Prix à confirmer, indique-le moi dans ta demande.</p>';
if(p.description)h+='<p>'+esc(p.description)+'</p>';if(p.arret_production)h+='<p class="note">En arrêt de production, jusqu\'à épuisement des stocks.</p>';if(p.famille==='Parfums'&&fs.some(f=>f.ml===15))h+='<p class="note">Les recharges de 15 ml s\'utilisent uniquement avec un étui de poche (voir la famille « Étuis de poche »).</p>';
h+='<p><button class="btn" id="add">Ajouter à ma demande</button></p>';
if(p.gel_douche||p.creme_corps){h+='<div class="box"><h2>À associer</h2>';
if(p.gel_douche)h+='<div class="row"><span>'+(p.gel_douche.image?'<img src="'+src(p.gel_douche.image)+'" alt="" width="44" height="44" style="vertical-align:middle;margin-right:8px;mix-blend-mode:multiply"> ':'')+'Gel douche parfumé '+p.gel_douche.ml+' ml – '+eur(p.gel_douche.prix)+'</span><button class="btn alt" data-x="gel">Ajouter</button></div>';
if(p.creme_corps)h+='<div class="row"><span>'+(p.creme_corps.image?'<img src="'+src(p.creme_corps.image)+'" alt="" width="44" height="44" style="vertical-align:middle;margin-right:8px;mix-blend-mode:multiply"> ':'')+'Crème de corps parfumée '+p.creme_corps.ml+' ml – '+eur(p.creme_corps.prix)+'</span><button class="btn alt" data-x="creme">Ajouter</button></div>';h+='</div>'}
h+='</div></div>';el.innerHTML=h;
$('#add').onclick=()=>{const r=$('input[name=fmt]:checked');cart.add({id:p.id,f:r?+r.value:-1,x:'',q:1})};
$$('[data-x]',el).forEach(b=>b.onclick=()=>cart.add({id:p.id,f:-1,x:b.dataset.x,q:1}))},
async demande(){const d=await load(),L=$('#lines');
const draw=()=>{const a=cart.get();L.innerHTML=a.length?a.map((it,i)=>{const p=d.find(x=>x.id===it.id);if(!p)return'';const l=line(p,it),fs=p.formats||[];
const sel=!it.x&&fs.length>1?'<select data-i="'+i+'" aria-label="Format">'+fs.map((f,j)=>'<option value="'+j+'"'+(j===it.f?' selected':'')+'>'+esc(lbl(f))+' – '+eur(f.prix)+'</option>').join('')+'</select>':'<small>'+esc(l.fmt)+(l.prix!=null?' – '+eur(l.prix):' – prix à confirmer')+'</small>';
return'<div class="row"><div><strong>'+esc(l.nom)+'</strong><br>'+sel+'</div><div class="q"><button data-i="'+i+'" data-d="-1" aria-label="Moins">−</button><span>'+it.q+'</span><button data-i="'+i+'" data-d="1" aria-label="Plus">+</button></div></div>'}).join(''):'<p>Ta demande est vide. <a href="catalogue.html">Parcourir le catalogue</a></p>'};
draw();
L.onclick=e=>{const b=e.target.closest('button[data-d]');if(!b)return;const a=cart.get(),it=a[+b.dataset.i];it.q+=+b.dataset.d;if(it.q<1)a.splice(+b.dataset.i,1);cart.set(a);draw()};
L.onchange=e=>{if(e.target.tagName==='SELECT'){const a=cart.get();a[+e.target.dataset.i].f=+e.target.value;cart.set(a);draw()}};
const adr=$('#adr');$$('input[name=remise]').forEach(r=>r.onchange=()=>{const l=$('input[name=remise]:checked').value==='livraison';$('#adrw').hidden=!l;adr.required=l});
$('#frm').onsubmit=async e=>{e.preventDefault();const er=$('#er');er.textContent='';const a=cart.get(),F=new FormData(e.target);
if(!a.length){er.textContent='Ajoute au moins un produit à ta demande.';return}
if(!F.get('email').trim()&&!F.get('phone').trim()){er.textContent='Indique un e-mail ou un téléphone (au moins un).';return}
if(F.get('botcheck')){return}
if(!C.WEB3FORMS_KEY||C.WEB3FORMS_KEY==='VOTRE_CLE_WEB3FORMS'){er.textContent='Le formulaire n\'est pas encore configuré (clé Web3Forms manquante dans js/config.js).';return}
const prods=a.map(it=>{const p=d.find(x=>x.id===it.id);if(!p)return'';const l=line(p,it);return'- '+l.nom+(p.reference?' (réf. '+p.reference+')':'')+' | '+l.fmt+' | quantité : '+it.q+(l.prix!=null?' | '+eur(l.prix)+' l\'unité (indicatif)':'')}).join('\n');
const o={access_key:C.WEB3FORMS_KEY,subject:'Nouvelle demande – CHOGAN Lille',from_name:'Site CHOGAN Lille',name:F.get('name'),email:F.get('email'),phone:F.get('phone'),'Mode de remise':F.get('remise')==='livraison'?'Livraison':'Retrait en main propre à Lille','Adresse':F.get('adresse')||'-','Produits demandés':prods,'Message':F.get('message')||'-','Newsletter':F.get('optin')?'OUI (consentement)':'non'};
const btn=$('#sb');btn.disabled=true;btn.textContent='Envoi…';
try{const r=await fetch('https://api.web3forms.com/submit',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(o)}),j=await r.json();
if(j.success){cart.set([]);location.href='merci.html'}else throw new Error(j.message)}catch(x){er.textContent='L\'envoi a échoué. Réessaie dans un instant.';btn.disabled=false;btn.textContent='Envoyer ma demande'}}}
};
document.addEventListener('DOMContentLoaded',()=>{chrome();const f=pages[document.body.dataset.page];if(f)f()});
})();
